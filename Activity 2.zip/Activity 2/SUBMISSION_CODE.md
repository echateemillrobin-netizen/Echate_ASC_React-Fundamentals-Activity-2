
## Concept 1: Components and JSX

### 01A.jsx
```jsx
export default function Exercise01A() {
  return (
    <main>
      <h2>Welcome to React</h2>
      <p>My name is Mina.</p>
    </main>
  );
}
```

### 01B.jsx
```jsx
export default function Exercise01B() {
  return (
    <main>
      <h2>Today's Schedule</h2>
      <p>9:00 AM - Web Development</p>
      <p>11:00 AM - Database Systems</p>
      <p>2:00 PM - Project Workshop</p>
    </main>
  );
}
```

### 01C.jsx
```jsx
export default function Exercise01C() {
  const studentName = "Mina";
  const course = "IT";

  return (
    <main>
      <h2>Student profile</h2>
      <p>Name: {studentName}</p>
      <p>Course: {course}</p>
    </main>
  );
}
```

## Concept 2: Props

### 02A.jsx
```jsx
function Greeting({ name }) {
  return <p>Hello, {name}!</p>;
}

export default function Exercise02A() {
  return (
    <main>
      <Greeting name="Ana" />
    </main>
  );
}
```

### 02B.jsx
```jsx
function StudentCard({ name, course }) {
  return (
    <article className="student-card">
      <p><strong>{name}</strong></p>
      <p>Course: {course}</p>
    </article>
  );
}

export default function Exercise02B() {
  return (
    <main>
      <h2>Students</h2>
      <StudentCard name="Ana" course="IT" />
      <StudentCard name="Leo" course="Design" />
    </main>
  );
}
```

### 02C.jsx
```jsx
function ScoreBadge({ student, points }) {
  return <p><strong>{student}</strong> - {points} points</p>;
}

export default function Exercise02C() {
  return (
    <main>
      <h2>Score board</h2>
      <ScoreBadge student="Ana" points={18} />
      <ScoreBadge student="Leo" points={15} />
    </main>
  );
}
```

## Concept 3: State

### 03A.jsx
```jsx
import { useState } from "react";

export default function Exercise03A() {
  const [present] = useState(0);

  return (
    <main>
      <h2>Attendance</h2>
      <p>Present: {present}</p>
    </main>
  );
}
```

### 03B.jsx
```jsx
import { useState } from "react";

export default function Exercise03B() {
  const [present, setPresent] = useState(0);

  return (
    <main>
      <h2>Attendance</h2>
      <p className="score-value">{present}</p>
      <button onClick={() => setPresent((previous) => previous + 1)} type="button">Add</button>
      <button onClick={() => setPresent(0)} type="button">Reset</button>
    </main>
  );
}
```

### 03C.jsx
```jsx
import { useState } from "react";

export default function Exercise03C() {
  const [score, setScore] = useState(0);

  return (
    <main>
      <h2>Limited score</h2>
      <p className="score-value">{score}</p>
      <button onClick={() => setScore((previous) => Math.min(previous + 5, 20))} type="button">Add 5 points</button>
      <button onClick={() => setScore(0)} type="button">Reset</button>
    </main>
  );
}
```

## Concept 4: Events

### 04A.jsx
```jsx
import { useState } from "react";

export default function Exercise04A() {
  const [message, setMessage] = useState("");

  return (
    <main>
      <h2>A little appreciation</h2>
      <button onClick={() => setMessage("Thank you!")} type="button">Say thanks</button>
      {message && <p role="status">{message}</p>}
    </main>
  );
}
```

### 04B.jsx
```jsx
import { useState } from "react";

export default function Exercise04B() {
  const [greeting, setGreeting] = useState("");

  return (
    <main>
      <h2>Choose a greeting</h2>
      <button onClick={() => setGreeting("Good morning!")} type="button">Morning</button>
      <button onClick={() => setGreeting("Good evening!")} type="button">Evening</button>
      {greeting && <p role="status">{greeting}</p>}
    </main>
  );
}
```

### 04C.jsx
```jsx
import { useState } from "react";

export default function Exercise04C() {
  const [count, setCount] = useState(0);

  return (
    <main>
      <h2>Cheer counter</h2>
      <p>Cheers: {count}</p>
      <button onClick={() => setCount((previous) => previous + 1)} type="button">Cheer</button>
      {count >= 3 && <p role="status">Great support!</p>}
    </main>
  );
}
```

## Concept 5: Conditional Rendering

### 05A.jsx
```jsx
export default function Exercise05A() {
  const isOpen = true;

  return (
    <main>
      <h2>Room status</h2>
      <p>{isOpen ? "Room open" : "Room closed"}</p>
    </main>
  );
}
```

### 05B.jsx
```jsx
export default function Exercise05B() {
  const score = 74;

  return (
    <main>
      <h2>Assessment</h2>
      <p>Score: {score}</p>
      <p>{score >= 75 ? "Pass" : "Retry"}</p>
    </main>
  );
}
```

### 05C.jsx
```jsx
export default function Exercise05C() {
  const temperature = 29;
  let message;

  if (temperature < 20) {
    message = "Cold";
  } else if (temperature < 30) {
    message = "Warm";
  } else {
    message = "Hot";
  }

  return (
    <main>
      <h2>Weather check</h2>
      <p>Temperature: {temperature} C</p>
      <p>{message}</p>
    </main>
  );
}
```

## Concept 6: Lists from Arrays

### 06A.jsx
```jsx
export default function Exercise06A() {
  const names = ["Ana", "Leo", "Mina"];

  return (
    <main>
      <h2>Class names</h2>
      <ul>
        {names.map((name) => <li key={name}>{name}</li>)}
      </ul>
    </main>
  );
}
```

### 06B.jsx
```jsx
export default function Exercise06B() {
  const books = [
    { id: 1, title: "The Little Prince" },
    { id: 2, title: "A Wizard of Earthsea" },
    { id: 3, title: "The Hobbit" },
  ];

  return (
    <main>
      <h2>Book shelf</h2>
      <ul>
        {books.map((book) => <li key={book.id}>{book.title}</li>)}
      </ul>
    </main>
  );
}
```

### 06C.jsx
```jsx
export default function Exercise06C() {
  const tasks = [
    { id: 1, label: "Read the chapter", done: true },
    { id: 2, label: "Review notes", done: false },
    { id: 3, label: "Submit the quiz", done: true },
    { id: 4, label: "Pack materials", done: false },
  ];
  const completed = tasks.filter((task) => task.done);

  return (
    <main>
      <h2>Completed tasks</h2>
      <p>Completed: {completed.length}</p>
      <ul>
        {completed.map((task) => <li key={task.id}>{task.label}</li>)}
      </ul>
    </main>
  );
}
```

## Concept 7: Inputs and Forms

### 07A.jsx
```jsx
import { useState } from "react";

export default function Exercise07A() {
  const [name, setName] = useState("");

  return (
    <main>
      <h2>Live greeting</h2>
      <label htmlFor="live-name">Your name</label>
      <input id="live-name" onChange={(event) => setName(event.target.value)} value={name} />
      {name && <p role="status">Hello, {name}!</p>}
    </main>
  );
}
```

### 07B.jsx
```jsx
import { useState } from "react";

export default function Exercise07B() {
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [hasError, setHasError] = useState(false);

  function handleSubmit(event) {
    event.preventDefault();
    const trimmedName = name.trim();
    setHasError(trimmedName === "");
    setMessage(trimmedName === "" ? "Please enter a name." : `Saved: ${trimmedName}`);
  }

  return (
    <main>
      <h2>Save your name</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="form-name">Your name</label>
        <input id="form-name" onChange={(event) => setName(event.target.value)} value={name} />
        <button type="submit">Submit</button>
      </form>
      {message && <output className={hasError ? "result-error" : "result-success"} role="status">{message}</output>}
    </main>
  );
}
```

### 07C.jsx
```jsx
import { useState } from "react";

export default function Exercise07C() {
  const [name, setName] = useState("");
  const [seats, setSeats] = useState("1");
  const [message, setMessage] = useState("");
  const [hasError, setHasError] = useState(false);

  function handleSubmit(event) {
    event.preventDefault();
    const seatCount = Number(seats);
    const trimmedName = name.trim();

    if (trimmedName === "" || !Number.isInteger(seatCount) || seatCount < 1 || seatCount > 4) {
      setHasError(true);
      setMessage("Enter a name and choose 1 to 4 seats.");
      return;
    }

    setHasError(false);
    setMessage(`Registered: ${trimmedName} for ${seatCount} ${seatCount === 1 ? "seat" : "seats"}.`);
  }

  return (
    <main>
      <h2>Event sign up</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="signup-name">Your name</label>
        <input id="signup-name" onChange={(event) => setName(event.target.value)} value={name} />
        <label htmlFor="signup-seats">Number of seats</label>
        <input
          id="signup-seats"
          max="4"
          min="1"
          onChange={(event) => setSeats(event.target.value)}
          type="number"
          value={seats}
        />
        <button type="submit">Register</button>
      </form>
      {message && <output className={hasError ? "result-error" : "result-success"} role="status">{message}</output>}
    </main>
  );
}
```

## Screenshot Evidence

Use screenshots from the running app at http://localhost:5173/ showing these completed checks:

- Concept 1: 01C showing Mina and IT.
- Concept 2: 02C showing Ana with 18 points and Leo with 15 points.
- Concept 3: 03C showing score 20 after five clicks.
- Concept 4: 04C showing Cheers: 3 and Great support!
- Concept 5: 05C showing 29 C and Warm.
- Concept 6: 06C showing Completed: 2 and the completed task labels.
- Concept 7: 07C showing Registered: Ana for 2 seats.
