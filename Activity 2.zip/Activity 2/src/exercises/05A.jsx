export default function Exercise05A() {
  const isOpen = true;

  return (
    <main>
      <h2>Room status</h2>
      <p>{isOpen ? "Room open" : "Room closed"}</p>
    </main>
  );
}