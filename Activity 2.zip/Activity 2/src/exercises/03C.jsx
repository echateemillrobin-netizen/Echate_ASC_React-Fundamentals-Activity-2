import { useState } from "react";

export default function Exercise03C() {
  const [score, setScore] = useState(0);

  return (
    <main>
      <h2>Limited score</h2>
      <p className="score-value">{score}</p>
      <button onClick={() => setScore((previous) => Math.min(previous + 5, 20))} type="button">Add 5 points</button>
      <button onClick={() => setScore(0)} type="button">Reset</button>
    </main>
  );
}