export default function Exercise06C() {
  const tasks = [
    { id: 1, label: "Read the chapter", done: true },
    { id: 2, label: "Review notes", done: false },
    { id: 3, label: "Submit the quiz", done: true },
    { id: 4, label: "Pack materials", done: false },
  ];
  const completed = tasks.filter((task) => task.done);

  return (
    <main>
      <h2>Completed tasks</h2>
      <p>Completed: {completed.length}</p>
      <ul>
        {completed.map((task) => <li key={task.id}>{task.label}</li>)}
      </ul>
    </main>
  );
}