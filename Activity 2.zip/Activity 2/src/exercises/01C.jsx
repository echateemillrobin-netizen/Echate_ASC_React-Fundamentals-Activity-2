export default function Exercise01C() {
  const studentName = "Mina";
  const course = "IT";

  return (
    <main>
      <h2>Student profile</h2>
      <p>Name: {studentName}</p>
      <p>Course: {course}</p>
    </main>
  );
}