import { useState } from "react";

export default function Exercise04A() {
  const [message, setMessage] = useState("");

  return (
    <main>
      <h2>A little appreciation</h2>
      <button onClick={() => setMessage("Thank you!")} type="button">Say thanks</button>
      {message && <p role="status">{message}</p>}
    </main>
  );
}