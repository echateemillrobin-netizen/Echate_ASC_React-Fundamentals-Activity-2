import { useState } from "react";

export default function Exercise07C() {
  const [name, setName] = useState("");
  const [seats, setSeats] = useState("1");
  const [message, setMessage] = useState("");
  const [hasError, setHasError] = useState(false);

  function handleSubmit(event) {
    event.preventDefault();
    const seatCount = Number(seats);
    const trimmedName = name.trim();

    if (trimmedName === "" || !Number.isInteger(seatCount) || seatCount < 1 || seatCount > 4) {
      setHasError(true);
      setMessage("Enter a name and choose 1 to 4 seats.");
      return;
    }

    setHasError(false);
    setMessage(`Registered: ${trimmedName} for ${seatCount} ${seatCount === 1 ? "seat" : "seats"}.`);
  }

  return (
    <main>
      <h2>Event sign up</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="signup-name">Your name</label>
        <input id="signup-name" onChange={(event) => setName(event.target.value)} value={name} />
        <label htmlFor="signup-seats">Number of seats</label>
        <input
          id="signup-seats"
          max="4"
          min="1"
          onChange={(event) => setSeats(event.target.value)}
          type="number"
          value={seats}
        />
        <button type="submit">Register</button>
      </form>
      {message && <output className={hasError ? "result-error" : "result-success"} role="status">{message}</output>}
    </main>
  );
}