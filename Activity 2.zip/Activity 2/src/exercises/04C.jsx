import { useState } from "react";

export default function Exercise04C() {
  const [count, setCount] = useState(0);

  return (
    <main>
      <h2>Cheer counter</h2>
      <p>Cheers: {count}</p>
      <button onClick={() => setCount((previous) => previous + 1)} type="button">Cheer</button>
      {count >= 3 && <p role="status">Great support!</p>}
    </main>
  );
}