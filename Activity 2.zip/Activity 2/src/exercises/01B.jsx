export default function Exercise01B() {
  return (
    <main>
      <h2>Today’s Schedule</h2>
      <p>9:00 AM — Web Development</p>
      <p>11:00 AM — Database Systems</p>
      <p>2:00 PM — Project Workshop</p>
    </main>
  );
}