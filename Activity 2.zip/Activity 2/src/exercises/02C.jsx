function ScoreBadge({ student, points }) {
  return <p><strong>{student}</strong> <span>·</span> {points} points</p>;
}

export default function Exercise02C() {
  return (
    <main>
      <h2>Score board</h2>
      <ScoreBadge student="Ana" points={18} />
      <ScoreBadge student="Leo" points={15} />
    </main>
  );
}