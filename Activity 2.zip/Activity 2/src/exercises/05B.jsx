export default function Exercise05B() {
  const score = 74;

  return (
    <main>
      <h2>Assessment</h2>
      <p>Score: {score}</p>
      <p>{score >= 75 ? "Pass" : "Retry"}</p>
    </main>
  );
}