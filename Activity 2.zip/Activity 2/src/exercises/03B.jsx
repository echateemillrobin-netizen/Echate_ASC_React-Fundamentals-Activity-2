import { useState } from "react";

export default function Exercise03B() {
  const [present, setPresent] = useState(0);

  return (
    <main>
      <h2>Attendance</h2>
      <p className="score-value">{present}</p>
      <button onClick={() => setPresent((previous) => previous + 1)} type="button">Add</button>
      <button onClick={() => setPresent(0)} type="button">Reset</button>
    </main>
  );
}