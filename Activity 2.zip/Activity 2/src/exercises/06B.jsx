export default function Exercise06B() {
  const books = [
    { id: 1, title: "The Little Prince" },
    { id: 2, title: "A Wizard of Earthsea" },
    { id: 3, title: "The Hobbit" },
  ];

  return (
    <main>
      <h2>Book shelf</h2>
      <ul>
        {books.map((book) => <li key={book.id}>{book.title}</li>)}
      </ul>
    </main>
  );
}