import { useState } from "react";

export default function Exercise07A() {
  const [name, setName] = useState("");

  return (
    <main>
      <h2>Live greeting</h2>
      <label htmlFor="live-name">Your name</label>
      <input id="live-name" onChange={(event) => setName(event.target.value)} value={name} />
      {name && <p role="status">Hello, {name}!</p>}
    </main>
  );
}