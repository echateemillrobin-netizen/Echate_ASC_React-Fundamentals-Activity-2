import { useState } from "react";

export default function Exercise03A() {
  const [present] = useState(0);

  return (
    <main>
      <h2>Attendance</h2>
      <p>Present: {present}</p>
    </main>
  );
}