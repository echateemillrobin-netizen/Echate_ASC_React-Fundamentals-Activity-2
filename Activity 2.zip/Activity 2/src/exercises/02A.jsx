function Greeting({ name }) {
  return <p>Hello, {name}!</p>;
}

export default function Exercise02A() {
  return (
    <main>
      <Greeting name="Ana" />
    </main>
  );
}