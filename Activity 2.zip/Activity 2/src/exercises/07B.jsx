import { useState } from "react";

export default function Exercise07B() {
  const [name, setName] = useState("");
  const [message, setMessage] = useState("");
  const [hasError, setHasError] = useState(false);

  function handleSubmit(event) {
    event.preventDefault();
    const trimmedName = name.trim();
    setHasError(trimmedName === "");
    setMessage(trimmedName === "" ? "Please enter a name." : `Saved: ${trimmedName}`);
  }

  return (
    <main>
      <h2>Save your name</h2>
      <form onSubmit={handleSubmit}>
        <label htmlFor="form-name">Your name</label>
        <input id="form-name" onChange={(event) => setName(event.target.value)} value={name} />
        <button type="submit">Submit</button>
      </form>
      {message && <output className={hasError ? "result-error" : "result-success"} role="status">{message}</output>}
    </main>
  );
}