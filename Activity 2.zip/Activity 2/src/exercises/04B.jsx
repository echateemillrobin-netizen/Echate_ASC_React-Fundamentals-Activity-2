import { useState } from "react";

export default function Exercise04B() {
  const [greeting, setGreeting] = useState("");

  return (
    <main>
      <h2>Choose a greeting</h2>
      <button onClick={() => setGreeting("Good morning!")} type="button">Morning</button>
      <button onClick={() => setGreeting("Good evening!")} type="button">Evening</button>
      {greeting && <p role="status">{greeting}</p>}
    </main>
  );
}