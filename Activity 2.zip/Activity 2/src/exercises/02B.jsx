function StudentCard({ name, course }) {
  return (
    <article className="student-card">
      <p><strong>{name}</strong></p>
      <p>Course: {course}</p>
    </article>
  );
}

export default function Exercise02B() {
  return (
    <main>
      <h2>Students</h2>
      <StudentCard name="Ana" course="IT" />
      <StudentCard name="Leo" course="Design" />
    </main>
  );
}