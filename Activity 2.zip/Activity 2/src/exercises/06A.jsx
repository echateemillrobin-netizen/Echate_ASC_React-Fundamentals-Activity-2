export default function Exercise06A() {
  const names = ["Ana", "Leo", "Mina"];

  return (
    <main>
      <h2>Class names</h2>
      <ul>
        {names.map((name) => <li key={name}>{name}</li>)}
      </ul>
    </main>
  );
}