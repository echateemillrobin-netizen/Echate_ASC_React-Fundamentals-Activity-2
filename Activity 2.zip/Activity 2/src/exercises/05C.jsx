export default function Exercise05C() {
  const temperature = 29;
  let message;

  if (temperature < 20) {
    message = "Cold";
  } else if (temperature < 30) {
    message = "Warm";
  } else {
    message = "Hot";
  }

  return (
    <main>
      <h2>Weather check</h2>
      <p>Temperature: {temperature}°C</p>
      <p>{message}</p>
    </main>
  );
}