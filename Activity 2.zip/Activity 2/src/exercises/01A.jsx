export default function Exercise01A() {
  return (
    <main>
      <h2>Welcome to React</h2>
      <p>My name is Mina.</p>
    </main>
  );
}