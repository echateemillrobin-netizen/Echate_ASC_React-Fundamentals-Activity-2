import { useState } from "react";
import Exercise01A from "./exercises/01A.jsx";
import Exercise01B from "./exercises/01B.jsx";
import Exercise01C from "./exercises/01C.jsx";
import Exercise02A from "./exercises/02A.jsx";
import Exercise02B from "./exercises/02B.jsx";
import Exercise02C from "./exercises/02C.jsx";
import Exercise03A from "./exercises/03A.jsx";
import Exercise03B from "./exercises/03B.jsx";
import Exercise03C from "./exercises/03C.jsx";
import Exercise04A from "./exercises/04A.jsx";
import Exercise04B from "./exercises/04B.jsx";
import Exercise04C from "./exercises/04C.jsx";
import Exercise05A from "./exercises/05A.jsx";
import Exercise05B from "./exercises/05B.jsx";
import Exercise05C from "./exercises/05C.jsx";
import Exercise06A from "./exercises/06A.jsx";
import Exercise06B from "./exercises/06B.jsx";
import Exercise06C from "./exercises/06C.jsx";
import Exercise07A from "./exercises/07A.jsx";
import Exercise07B from "./exercises/07B.jsx";
import Exercise07C from "./exercises/07C.jsx";

const concepts = [
	{
		title: "Components and JSX",
		exercises: [
			{ id: "01A", level: "Easy", title: "Welcome message", Component: Exercise01A },
			{ id: "01B", level: "Medium", title: "Class schedule", Component: Exercise01B },
			{ id: "01C", level: "Challenge", title: "Simple profile", Component: Exercise01C },
		],
	},
	{
		title: "Props",
		exercises: [
			{ id: "02A", level: "Easy", title: "Greeting by name", Component: Exercise02A },
			{ id: "02B", level: "Medium", title: "Two student cards", Component: Exercise02B },
			{ id: "02C", level: "Challenge", title: "Score badge", Component: Exercise02C },
		],
	},
	{
		title: "State",
		exercises: [
			{ id: "03A", level: "Easy", title: "Attendance counter", Component: Exercise03A },
			{ id: "03B", level: "Medium", title: "Counter and reset", Component: Exercise03B },
			{ id: "03C", level: "Challenge", title: "Score with a limit", Component: Exercise03C },
		],
	},
	{
		title: "Events",
		exercises: [
			{ id: "04A", level: "Easy", title: "Thank you button", Component: Exercise04A },
			{ id: "04B", level: "Medium", title: "Choose a greeting", Component: Exercise04B },
			{ id: "04C", level: "Challenge", title: "Cheer counter", Component: Exercise04C },
		],
	},
	{
		title: "Conditional rendering",
		exercises: [
			{ id: "05A", level: "Easy", title: "Room status", Component: Exercise05A },
			{ id: "05B", level: "Medium", title: "Pass or retry", Component: Exercise05B },
			{ id: "05C", level: "Challenge", title: "Weather message", Component: Exercise05C },
		],
	},
	{
		title: "Lists from arrays",
		exercises: [
			{ id: "06A", level: "Easy", title: "Names on the board", Component: Exercise06A },
			{ id: "06B", level: "Medium", title: "Book titles", Component: Exercise06B },
			{ id: "06C", level: "Challenge", title: "Completed tasks", Component: Exercise06C },
		],
	},
	{
		title: "Inputs and forms",
		exercises: [
			{ id: "07A", level: "Easy", title: "Live name greeting", Component: Exercise07A },
			{ id: "07B", level: "Medium", title: "Name form", Component: Exercise07B },
			{ id: "07C", level: "Challenge", title: "Event sign up", Component: Exercise07C },
		],
	},
];

export default function App() {
	const [activeId, setActiveId] = useState("01A");
	const exercises = concepts.flatMap((concept) => concept.exercises);
	const activeExercise = exercises.find((exercise) => exercise.id === activeId);
	const ActiveComponent = activeExercise.Component;

	return (
		<div className="app-shell">
			<header className="topbar">
				<a className="brand" href="#top" aria-label="React Practice Lab home">
					<span className="brand-mark" aria-hidden="true">R</span>
					<span>React Practice Lab</span>
				</a>
				<span className="progress-count">{exercises.length} exercises</span>
			</header>

			<div className="workspace" id="top">
				<aside className="sidebar" aria-label="Exercise navigation">
					<p className="sidebar-kicker">YOUR PRACTICE</p>
					{concepts.map((concept, index) => (
						<section className="concept-group" key={concept.title}>
							<h2><span>{String(index + 1).padStart(2, "0")}</span>{concept.title}</h2>
							<div className="exercise-links">
								{concept.exercises.map((exercise) => (
									<button
										aria-current={activeId === exercise.id ? "page" : undefined}
										className={`exercise-link${activeId === exercise.id ? " is-active" : ""}`}
										key={exercise.id}
										onClick={() => setActiveId(exercise.id)}
										type="button"
									>
										<span className="exercise-id">{exercise.id}</span>
										<span className="exercise-title">{exercise.title}</span>
										<span className="exercise-level">{exercise.level}</span>
									</button>
								))}
							</div>
						</section>
					))}
				</aside>

				<div className="content">
					<div className="content-heading">
						<div>
							<p className="eyebrow">EXERCISE {activeExercise.id}</p>
							<h1>{activeExercise.title}</h1>
						</div>
						<span className={`level-tag level-${activeExercise.level.toLowerCase()}`}>
							{activeExercise.level}
						</span>
					</div>
					<div className="exercise-stage">
						<ActiveComponent />
					</div>
				</div>
			</div>
		</div>
	);
}
